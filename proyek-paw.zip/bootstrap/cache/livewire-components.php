<?php return array (
  'toggle-button' => 'App\\Http\\Livewire\\ToggleButton',
);