

<?php $__env->startSection('content'); ?>

<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title ">Kelola Pengguna</h4>
              <p class="card-category"> Disini Anda dapat mengelola pengguna</p>
            </div>

            <div class="card-body">
              <div class="row">
                  <div class="col-12 text-right">

                    <button class="btn btn-round btn-primary text-right" data-toggle="modal" data-target="#signupModal">
                        <i class="material-icons">assignment</i>
                        Tambah Pengguna
                    </button>

                    <!-- Modal Tambah Pengguna -->
                    <div class="modal fade" id="signupModal" tabindex="-1" role="dialog">
                      <div class="modal-dialog modal-signup" role="document">
                        <div class="modal-content">
                          <div class="card card-signup card-plain">
                            <div class="modal-header">
                              <h5 class="modal-title card-title">Tambah Pengguna</h5>
                              <button type="submit" class="close" data-dismiss="modal" aria-label="Close">
                              <i class="material-icons">clear</i>
                              </button>
                            </div>
                            <div class="modal-body">
                              <div class="row">
                                <div class="col-sm">
                                  <form id="tambahPenggunaForm" class="form" method="post" action="/user">
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body">
                                      <div class="form-group">
                                        <div class="input-group">
                                          <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="material-icons">face</i></div>
                                          </div>
                                            <input type="text" class="form-control" id="name" name="name" placeholder="Nama">
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <div class="input-group">
                                          <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="material-icons">email</i></div>
                                          </div>
                                            <input type="text" class="form-control" id="email" name="email" placeholder="Email">
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <div class="input-group">
                                          <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="material-icons">lock_outline</i></div>
                                          </div>
                                            <input type="password" placeholder="Password" id="password" name="password" class="form-control" />
                                        </div>
                                      </div>

                                      <div class="form-check text-center">
                                        <label class="form-check-label">
                                            <input class="form-check-input" type="checkbox" value="" checked>
                                            <span class="form-check-sign">
                                                <span class="check"></span>
                                            </span>
                                            Saya setuju dengan <a href="#something">terms dan conditions</a>.
                                        </label>
                                      </div>
                                    </div>
                                    <div class="modal-footer justify-content-center">
                                    <button class="btn btn-primary btn-round" type="submit">Tambah</button>
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
              </div>

             
              
              <div class="table-responsive">          
                <table class="table">
                  <thead class=" text-primary">
                    <tr>
                      <th>Nama</th>
                      <th>Email</th>
                      <th>Terakhir dimodifikasi</th>
                      <th class="text-right">Aksi</th>
                    </tr>
                  </thead>
                
                  <tbody>
                    <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($usr->name); ?></td>
                      <td><?php echo e($usr->email); ?></td>
                      <td><?php echo e($usr->updated_at); ?></td>
                      <td class="td-actions text-right">

                        <div class="container-fluid">
                          <div class="row">
                            <div class="col-12 text-right">
                              <form action="/user/<?php echo e($usr->id); ?>" method="post">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-danger text-right" data-toggle="modal" data-target="#hapusModal">
                                    Hapus Pengguna
                                </button>
                              </form>
                            </div>
                          </div>
                        </div>

                        <div class="container-fluid">
                          <div class="row">
                            <div class="col-12 text-right">
                              <div class="btn-group">    
                                  <button class="btn btn-sm btn-success text-right" data-toggle="modal" data-target="#editModal<?php echo e($usr->id); ?>">
                                    Edit Pengguna
                                  </button>

                                <!-- Modal Edit Pengguna -->
                                <div class="modal fade" id="editModal<?php echo e($usr->id); ?>" tabindex="-1" role="dialog">
                                  <div class="modal-dialog modal-signup" role="document">
                                    <div class="modal-content">
                                      <div class="card card-signup card-plain">
                                        <div class="modal-header">
                                          <button type="submit" class="close" data-dismiss="modal" aria-label="Close">
                                            <i class="material-icons">clear</i>
                                          </button>
                                          <div class="modal-body">
                                            <div class="row">
                                              <div class="col-md-12">
                                                <form id= "editFormID" method="post" action="<?php echo e(route('profile.update')); ?>" autocomplete="off" class="form-horizontal">
                                                  <?php echo csrf_field(); ?>
                                                  <?php echo method_field('put'); ?>

                                                  <div class="card ">
                                                    <div class="card-header card-header-primary">
                                                        <h4 class="card-title"><?php echo e(__('Edit Profile')); ?></h4>
                                                        <p class="card-category"><?php echo e(__('Informasi Pengguna')); ?></p>
                                                    </div>

                                                    <div class="card-body ">
                                                        <?php if(session('status')): ?>
                                                        <div class="row">
                                                            <div class="col-sm-12">
                                                              <div class="alert alert-success">
                                                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                                    <i class="material-icons">close</i>
                                                                  </button>
                                                                  <span><?php echo e(session('status')); ?></span>
                                                              </div>
                                                            </div>
                                                        </div>
                                                        <?php endif; ?>

                                                        <div class="row">
                                                        <label class="col-sm-2 col-form-label"><?php echo e(__('Nama')); ?></label>
                                                          <div class="col-sm-7">
                                                              <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                                              <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="input-name" type="text" 
                                                              placeholder="<?php echo e(__('Nama')); ?>" value="<?php echo e($usr->name); ?>" required="true" aria-reqired="true"/>
                                                              <?php if($errors->has('name')): ?>
                                                                  <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('name')); ?></span>
                                                              <?php endif; ?>
                                                              </div>
                                                          </div>
                                                        </div>

                                                        <div class="row">
                                                        <label class="col-sm-2 col-form-label"><?php echo e(__('Email')); ?></label>
                                                          <div class="col-sm-7">
                                                            <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                                            <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="input-email" type="email" 
                                                            placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e($usr->email); ?>" required />
                                                            <?php if($errors->has('email')): ?>
                                                              <span id="email-error" class="error text-danger" for="input-email"><?php echo e($errors->first('email')); ?></span>
                                                            <?php endif; ?>
                                                            </div>
                                                          </div>
                                                        </div>
                                                    </div>

                                                    <div class="card-footer ml-auto mr-auto">
                                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                    </div>
                                                  </div>
                                                </form>
                                              </div>
                                            </div>
                                          </div>       
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                      </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>

              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'user-management', 'titlePage' => __('Kelola Pengguna')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyek-pwa\resources\views/users/index.blade.php ENDPATH**/ ?>