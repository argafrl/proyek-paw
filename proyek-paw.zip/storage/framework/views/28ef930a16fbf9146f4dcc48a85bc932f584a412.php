<div class="togglebutton">
    <label>
    <input wire:model="state" type="checkbox" name="toggle" id="toggle">
        <span class="toggle"></span>
    </label>
</div><?php /**PATH C:\xampp\htdocs\proyek-pwa\resources\views/livewire/toggle-button.blade.php ENDPATH**/ ?>